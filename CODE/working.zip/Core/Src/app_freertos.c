/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : app_freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#define USE_FULL_LL_DRIVER 1
#include "lwesp_opts.h"
#include "lwesp/lwesp_includes.h"
#include "lwesp/lwesp.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

/* USER CODE END Variables */
/* Definitions for defaultTask */
osThreadId_t defaultTaskHandle;
const osThreadAttr_t defaultTask_attributes = {
  .name = "defaultTask",
  .priority = (osPriority_t) osPriorityNormal,
  .stack_size = 128 * 4
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */
void init_thread(void* argument);
/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
	/* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
	/* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
	/* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
	/* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of defaultTask */
  defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
	const osThreadAttr_t attr = {
		.stack_size = 512
	};
	osThreadNew(init_thread, NULL, &attr);
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
	/* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  /* USER CODE BEGIN StartDefaultTask */
	/* Infinite loop */
	for (;;)
	{
		HAL_GPIO_TogglePin(LED_GPIO_Port, LED_Pin);
		osDelay(500);
	}
  /* USER CODE END StartDefaultTask */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */
lwespr_t examples_common_lwesp_callback_func(lwesp_evt_t* evt)
{
	switch (lwesp_evt_get_type(evt))
	{
		case LWESP_EVT_AT_VERSION_NOT_SUPPORTED:
		{
			lwesp_sw_version_t v_min, v_curr;

			lwesp_get_min_at_fw_version(&v_min);
			lwesp_get_current_at_fw_version(&v_curr);

			printf("Current ESP[8266/32[-C3]] AT version is not supported by the library\r\n");
			printf("Minimum required AT version is: %08X\r\n", (unsigned)v_min.version);
			printf("Current AT version is: %08X\r\n", (unsigned)v_curr.version);
			break;
		}
		case LWESP_EVT_INIT_FINISH:
		{
			printf("Library initialized!\r\n");
			break;
		}
		case LWESP_EVT_RESET_DETECTED:
		{
			printf("Device reset detected!\r\n");
			break;
		}
		default:
			break;
	}
	return lwespOK;
}

void prv_cmd_event_fn(lwespr_t status, void* arg){
	printf("");
}

void init_thread(void* arg)
{
	/* Initialize ESP with common callback for all examples */
	printf("Initializing LwESP\r\n");
	if (lwesp_init(examples_common_lwesp_callback_func, 1) != lwespOK)
	{
		printf("Cannot initialize LwESP!\r\n");
	}
	else
	{
		printf("LwESP initialized!\r\n");
	}

	/*
	 * Continuously try to connect to WIFI network
	 * but only in case device is not already connected
	 */
	while (1)
	{
		uint8_t suc =!lwesp_sta_is_joined();
		if (suc)
		{
			/*
			 * Connect to access point.
			 *
			 * Try unlimited time until access point accepts us.
			 * Check for station_manager.c to define preferred access points ESP should connect to
			 */
			if (lwesp_sta_join("SauronNet.Horcicka1", "10821082", NULL, prv_cmd_event_fn, 0, 0) == lwespOK)
			{
				printf("Connected to AP\n");
			}
		}

		osDelay(1000);
	}
}
/* USER CODE END Application */

