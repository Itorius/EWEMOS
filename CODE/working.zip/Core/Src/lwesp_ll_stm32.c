#include "lwesp/lwesp.h"
#include "lwesp/lwesp_input.h"
#include "lwesp/lwesp_mem.h"
#include "system/lwesp_ll.h"

#include "stm32l5xx_ll_bus.h"
#include "stm32l5xx_ll_dma.h"
#include "stm32l5xx_ll_gpio.h"
#include "stm32l5xx_ll_rcc.h"
#include "stm32l5xx_ll_usart.h"

#define LWESP_USART                   USART2
#define LWESP_USART_CLK               LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_USART2)
#define LWESP_USART_IRQ               USART2_IRQn
#define LWESP_USART_IRQHANDLER        USART2_IRQHandler
#define LWESP_USART_RDR_NAME          DR

/* DMA settings */
#define LWESP_USART_DMA               DMA1
#define LWESP_USART_DMA_CLK           LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_DMA1)
#define LWESP_USART_DMA_RX_CH         LL_DMA_CHANNEL_6
#define LWESP_USART_DMA_RX_IRQ        DMA1_Channel6_IRQn
#define LWESP_USART_DMA_RX_IRQHANDLER DMA1_Channel6_IRQHandler

/* DMA flags management */
#define LWESP_USART_DMA_RX_IS_TC      LL_DMA_IsActiveFlag_TC5(LWESP_USART_DMA)
#define LWESP_USART_DMA_RX_IS_HT      LL_DMA_IsActiveFlag_HT5(LWESP_USART_DMA)
#define LWESP_USART_DMA_RX_CLEAR_TC   LL_DMA_ClearFlag_TC5(LWESP_USART_DMA)
#define LWESP_USART_DMA_RX_CLEAR_HT   LL_DMA_ClearFlag_HT5(LWESP_USART_DMA)

/* USART TX PIN */
#define LWESP_USART_TX_PORT_CLK       LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOA)
#define LWESP_USART_TX_PORT           GPIOA
#define LWESP_USART_TX_PIN            LL_GPIO_PIN_2
#define LWESP_USART_TX_PIN_AF         LL_GPIO_AF_7

/* USART RX PIN */
#define LWESP_USART_RX_PORT_CLK       LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOA)
#define LWESP_USART_RX_PORT           GPIOA
#define LWESP_USART_RX_PIN            LL_GPIO_PIN_3
#define LWESP_USART_RX_PIN_AF         LL_GPIO_AF_7

///* RESET PIN */
//#define LWESP_RESET_PORT_CLK          LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOD)
//#define LWESP_RESET_PORT              GPIOD
//#define LWESP_RESET_PIN               LL_GPIO_PIN_1
//
///* GPIO0 PIN */
//#define LWESP_GPIO0_PORT_CLK          LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOD)
//#define LWESP_GPIO0_PORT              GPIOD
//#define LWESP_GPIO0_PIN               LL_GPIO_PIN_4
//
///* GPIO2 PIN */
//#define LWESP_GPIO2_PORT_CLK          LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOD)
//#define LWESP_GPIO2_PORT              GPIOD
//#define LWESP_GPIO2_PIN               LL_GPIO_PIN_7
//
///* CH_PD PIN */
//#define LWESP_CH_PD_PORT_CLK          LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOD)
//#define LWESP_CH_PD_PORT              GPIOD
//#define LWESP_CH_PD_PIN               LL_GPIO_PIN_3

#if !__DOXYGEN__

#if !LWESP_CFG_INPUT_USE_PROCESS
#error "LWESP_CFG_INPUT_USE_PROCESS must be enabled in `lwesp_config.h` to use this driver."
#endif /* LWESP_CFG_INPUT_USE_PROCESS */

#if !defined(LWESP_USART_DMA_RX_BUFF_SIZE)
//#define LWESP_USART_DMA_RX_BUFF_SIZE 0x1000
#define LWESP_USART_DMA_RX_BUFF_SIZE 128
#endif /* !defined(LWESP_USART_DMA_RX_BUFF_SIZE) */

#if !defined(LWESP_MEM_SIZE)
#define LWESP_MEM_SIZE 0x4000
#endif /* !defined(LWESP_MEM_SIZE) */

#if !defined(LWESP_USART_RDR_NAME)
#define LWESP_USART_RDR_NAME RDR
#endif /* !defined(LWESP_USART_RDR_NAME) */

/* USART memory */
static uint8_t usart_mem[LWESP_USART_DMA_RX_BUFF_SIZE];
static uint8_t is_running, initialized;
static size_t old_pos;

/* USART thread */
static void usart_ll_thread(void* arg);

static osThreadId_t usart_ll_thread_id;

/* Message queue */
static osMessageQueueId_t usart_ll_mbox_id;

/**
 * \brief           USART data processing
 */
static void usart_ll_thread(void* arg)
{
	size_t pos;

	LWESP_UNUSED(arg);

	while (1)
	{
		void* d;
		/* Wait for the event message from DMA or USART */
		osMessageQueueGet(usart_ll_mbox_id, &d, NULL, osWaitForever);

		/* Read data */
#if defined(LWESP_USART_DMA_RX_STREAM)
		pos = sizeof(usart_mem) - LL_DMA_GetDataLength(LWESP_USART_DMA, LWESP_USART_DMA_RX_STREAM);
#else
		uint32_t len=LL_DMA_GetDataLength(LWESP_USART_DMA, LWESP_USART_DMA_RX_CH);
		printf("%lu",len);
		pos = sizeof(usart_mem) -len;
#endif /* defined(LWESP_USART_DMA_RX_STREAM) */
		if (pos != old_pos && is_running)
		{
			if (pos > old_pos)
			{
				lwesp_input_process(&usart_mem[old_pos], pos - old_pos);
			}
			else
			{
				lwesp_input_process(&usart_mem[old_pos], sizeof(usart_mem) - old_pos);
				if (pos > 0)
				{
					lwesp_input_process(&usart_mem[0], pos);
				}
			}
			old_pos = pos;
		}
	}
}

/**
 * \brief           Configure UART using DMA for receive in double buffer mode and IDLE line detection
 */
static void prv_configure_uart(uint32_t baudrate)
{
	static LL_USART_InitTypeDef usart_init;
	static LL_DMA_InitTypeDef dma_init;
	LL_GPIO_InitTypeDef gpio_init;

	if (!initialized)
	{
		LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_USART2);
		LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOA);
		LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_DMA1);


		/* Enable peripheral clocks */
		LWESP_USART_CLK;
		LWESP_USART_DMA_CLK;
		LWESP_USART_TX_PORT_CLK;
		LWESP_USART_RX_PORT_CLK;

#if defined(LWESP_RESET_PIN)
		LWESP_RESET_PORT_CLK;
#endif /* defined(LWESP_RESET_PIN) */

#if defined(LWESP_GPIO0_PIN)
		LWESP_GPIO0_PORT_CLK;
#endif /* defined(LWESP_GPIO0_PIN) */

#if defined(LWESP_GPIO2_PIN)
		LWESP_GPIO2_PORT_CLK;
#endif /* defined(LWESP_GPIO2_PIN) */

#if defined(LWESP_CH_PD_PIN)
		LWESP_CH_PD_PORT_CLK;
#endif /* defined(LWESP_CH_PD_PIN) */

		/* Global pin configuration */
		LL_GPIO_StructInit(&gpio_init);
		gpio_init.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
		gpio_init.Pull = LL_GPIO_PULL_UP;
		gpio_init.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
		gpio_init.Mode = LL_GPIO_MODE_OUTPUT;

#if defined(LWESP_RESET_PIN)
		/* Configure RESET pin */
		gpio_init.Pin = LWESP_RESET_PIN;
		LL_GPIO_Init(LWESP_RESET_PORT, &gpio_init);
#endif /* defined(LWESP_RESET_PIN) */

#if defined(LWESP_GPIO0_PIN)
		/* Configure GPIO0 pin */
		gpio_init.Pin = LWESP_GPIO0_PIN;
		LL_GPIO_Init(LWESP_GPIO0_PORT, &gpio_init);
		LL_GPIO_SetOutputPin(LWESP_GPIO0_PORT, LWESP_GPIO0_PIN);
#endif /* defined(LWESP_GPIO0_PIN) */

#if defined(LWESP_GPIO2_PIN)
		/* Configure GPIO2 pin */
		gpio_init.Pin = LWESP_GPIO2_PIN;
		LL_GPIO_Init(LWESP_GPIO2_PORT, &gpio_init);
		LL_GPIO_SetOutputPin(LWESP_GPIO2_PORT, LWESP_GPIO2_PIN);
#endif /* defined(LWESP_GPIO2_PIN) */

#if defined(LWESP_CH_PD_PIN)
		/* Configure CH_PD pin */
		gpio_init.Pin = LWESP_CH_PD_PIN;
		LL_GPIO_Init(LWESP_CH_PD_PORT, &gpio_init);
		LL_GPIO_SetOutputPin(LWESP_CH_PD_PORT, LWESP_CH_PD_PIN);
#endif /* defined(LWESP_CH_PD_PIN) */

		/* Configure USART pins */
		gpio_init.Mode = LL_GPIO_MODE_ALTERNATE;

		/* TX PIN */
		gpio_init.Alternate = LWESP_USART_TX_PIN_AF;
		gpio_init.Pin = LWESP_USART_TX_PIN;
		LL_GPIO_Init(LWESP_USART_TX_PORT, &gpio_init);

		/* RX PIN */
		gpio_init.Alternate = LWESP_USART_RX_PIN_AF;
		gpio_init.Pin = LWESP_USART_RX_PIN;
		LL_GPIO_Init(LWESP_USART_RX_PORT, &gpio_init);

		/* Configure UART */
		LL_USART_DeInit(LWESP_USART);
		LL_USART_StructInit(&usart_init);
		usart_init.BaudRate = baudrate;
		usart_init.DataWidth = LL_USART_DATAWIDTH_8B;
		usart_init.HardwareFlowControl = LL_USART_HWCONTROL_NONE;
		usart_init.OverSampling = LL_USART_OVERSAMPLING_16;
		usart_init.Parity = LL_USART_PARITY_NONE;
		usart_init.StopBits = LL_USART_STOPBITS_1;
		usart_init.TransferDirection = LL_USART_DIRECTION_TX_RX;
		LL_USART_Init(LWESP_USART, &usart_init);
		LL_USART_ConfigAsyncMode(USART2);
		LL_USART_DisableFIFO(USART2);
		LL_USART_EnableDMAReq_RX(USART2);
		LL_USART_EnableIT_IDLE(USART2);


		/* Enable USART interrupts */
		NVIC_SetPriority(LWESP_USART_IRQ, NVIC_EncodePriority(NVIC_GetPriorityGrouping(), 5, 1));
		NVIC_EnableIRQ(LWESP_USART_IRQ);

		LL_DMA_SetPeriphRequest(DMA1, LL_DMA_CHANNEL_6, LL_DMAMUX_REQ_USART2_RX);
		LL_DMA_SetDataTransferDirection(DMA1, LL_DMA_CHANNEL_6, LL_DMA_DIRECTION_PERIPH_TO_MEMORY);
		LL_DMA_SetChannelPriorityLevel(DMA1, LL_DMA_CHANNEL_6, LL_DMA_PRIORITY_LOW);
		LL_DMA_SetMode(DMA1, LL_DMA_CHANNEL_6, LL_DMA_MODE_CIRCULAR);
		LL_DMA_SetPeriphIncMode(DMA1, LL_DMA_CHANNEL_6, LL_DMA_PERIPH_NOINCREMENT);
		LL_DMA_SetMemoryIncMode(DMA1, LL_DMA_CHANNEL_6, LL_DMA_MEMORY_INCREMENT);
		LL_DMA_SetPeriphSize(DMA1, LL_DMA_CHANNEL_6, LL_DMA_PDATAALIGN_BYTE);
		LL_DMA_SetMemorySize(DMA1, LL_DMA_CHANNEL_6, LL_DMA_MDATAALIGN_BYTE);
		LL_DMA_SetPeriphAddress(DMA1, LL_DMA_CHANNEL_6, LL_USART_DMA_GetRegAddr(USART2, LL_USART_DMA_REG_DATA_RECEIVE));
		LL_DMA_SetMemoryAddress(DMA1, LL_DMA_CHANNEL_6, (uint32_t)usart_mem);
		LL_DMA_SetDataLength(DMA1, LL_DMA_CHANNEL_6, sizeof (usart_mem));

		/* Enable DMA interrupts */
		LL_DMA_EnableIT_HT(LWESP_USART_DMA, LWESP_USART_DMA_RX_CH);
		LL_DMA_EnableIT_TC(LWESP_USART_DMA, LWESP_USART_DMA_RX_CH);
		LL_DMA_EnableIT_TE(LWESP_USART_DMA, LWESP_USART_DMA_RX_CH);
		is_running = 0;

		/* Enable DMA interrupts */
		NVIC_SetPriority(LWESP_USART_DMA_RX_IRQ, NVIC_EncodePriority(NVIC_GetPriorityGrouping(), 5, 0));
		NVIC_EnableIRQ(LWESP_USART_DMA_RX_IRQ);

		old_pos = 0;
		is_running = 1;

		/* Start DMA and USART */
		LL_DMA_EnableChannel(LWESP_USART_DMA, LWESP_USART_DMA_RX_CH);
		LL_USART_Enable(LWESP_USART);
	}
	else
	{
//		osDelay(10);
//		LL_USART_Disable(LWESP_USART);
//		usart_init.BaudRate = baudrate;
//		LL_USART_Init(LWESP_USART, &usart_init);
//		LL_USART_Enable(LWESP_USART);
	}

	/* Create mbox and start thread */
	if (usart_ll_mbox_id == NULL)
	{
		usart_ll_mbox_id = osMessageQueueNew(10, sizeof(void*), NULL);
	}
	if (usart_ll_thread_id == NULL)
	{
		const osThreadAttr_t attr = { .stack_size = /*1536*/1024 };
		usart_ll_thread_id = osThreadNew(usart_ll_thread, usart_ll_mbox_id, &attr);
	}
}

#if defined(LWESP_RESET_PIN)
/**
 * \brief           Hardware reset callback
 */
static uint8_t
prv_reset_device(uint8_t state) {
	if (state) { /* Activate reset line */
		LL_GPIO_ResetOutputPin(LWESP_RESET_PORT, LWESP_RESET_PIN);
	} else {
		LL_GPIO_SetOutputPin(LWESP_RESET_PORT, LWESP_RESET_PIN);
	}
	return 1;
}
#endif /* defined(LWESP_RESET_PIN) */

/**
 * \brief           Send data to ESP device
 * \param[in]       data: Pointer to data to send
 * \param[in]       len: Number of bytes to send
 * \return          Number of bytes sent
 */
static size_t
prv_send_data(const void* data, size_t len)
{
	const uint8_t* d = data;

	for (size_t i = 0; i < len; ++i, ++d)
	{
		LL_USART_TransmitData8(LWESP_USART, *d);
		while (!LL_USART_IsActiveFlag_TXE(LWESP_USART))
		{}
	}
	return len;
}

/**
 * \brief           Callback function called from initialization process
 */
lwespr_t
lwesp_ll_init(lwesp_ll_t* ll)
{
#if !LWESP_CFG_MEM_CUSTOM
	static uint8_t memory[LWESP_MEM_SIZE];
	const lwesp_mem_region_t mem_regions[] = { { memory, sizeof(memory) } };

	if (!initialized)
	{
		lwesp_mem_assignmemory(mem_regions, LWESP_ARRAYSIZE(mem_regions)); /* Assign memory for allocations */
	}
#endif /* !LWESP_CFG_MEM_CUSTOM */

	if (!initialized)
	{
		ll->send_fn = prv_send_data; /* Set callback function to send data */
#if defined(LWESP_RESET_PIN)
		ll->reset_fn = prv_reset_device; /* Set callback for hardware reset */
#endif                                   /* defined(LWESP_RESET_PIN) */
	}

	prv_configure_uart(ll->uart.baudrate); /* Initialize UART for communication */
	initialized = 1;
	return lwespOK;
}

/**
 * \brief           Callback function to de-init low-level communication part
 */
lwespr_t
lwesp_ll_deinit(lwesp_ll_t* ll)
{
	if (usart_ll_mbox_id != NULL)
	{
		osMessageQueueId_t tmp = usart_ll_mbox_id;
		usart_ll_mbox_id = NULL;
		osMessageQueueDelete(tmp);
	}
	if (usart_ll_thread_id != NULL)
	{
		osThreadId_t tmp = usart_ll_thread_id;
		usart_ll_thread_id = NULL;
		osThreadTerminate(tmp);
	}
	initialized = 0;
	LWESP_UNUSED(ll);
	return lwespOK;
}

/**
 * \brief           UART global interrupt handler
 */

void LWESP_USART_IRQHANDLER(void)
{
	void* d = (void *)1;

	/* Check for IDLE line interrupt */
	if (LL_USART_IsEnabledIT_IDLE(USART2) && LL_USART_IsActiveFlag_IDLE(USART2)) {
		LL_USART_ClearFlag_IDLE(USART2);        /* Clear IDLE line flag */
		osMessageQueuePut(usart_ll_mbox_id, &d, 0, 0);  /* Write data to queue. Do not use wait function! */
	}

//	LL_USART_ClearFlag_IDLE(LWESP_USART);
//	LL_USART_ClearFlag_PE(LWESP_USART);
//	LL_USART_ClearFlag_FE(LWESP_USART);
//	LL_USART_ClearFlag_ORE(LWESP_USART);
//	LL_USART_ClearFlag_NE(LWESP_USART);
//
//	if (usart_ll_mbox_id != NULL)
//	{
//		void* d = (void*)1;
//		osMessageQueuePut(usart_ll_mbox_id, &d, 0, 0);
//	}
}

/**
 * \brief           UART DMA stream/channel handler
 */
void LWESP_USART_DMA_RX_IRQHANDLER(void)
{
	void* d = (void *)1;

	/* Check half-transfer complete interrupt */
	if (LL_DMA_IsEnabledIT_HT(DMA1, LL_DMA_CHANNEL_6) && LL_DMA_IsActiveFlag_HT6(DMA1)) {
		LL_DMA_ClearFlag_HT6(DMA1);             /* Clear half-transfer complete flag */
		osMessageQueuePut(usart_ll_mbox_id, &d, 0, 0);  /* Write data to queue. Do not use wait function! */
	}

	/* Check transfer-complete interrupt */
	if (LL_DMA_IsEnabledIT_TC(DMA1, LL_DMA_CHANNEL_6) && LL_DMA_IsActiveFlag_TC6(DMA1)) {
		LL_DMA_ClearFlag_TC6(DMA1);             /* Clear transfer complete flag */
		osMessageQueuePut(usart_ll_mbox_id, &d, 0, 0);  /* Write data to queue. Do not use wait function! */
	}


}

#endif /* !__DOXYGEN__ */
