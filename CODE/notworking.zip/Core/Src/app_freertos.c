/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : app_freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#define USE_FULL_LL_DRIVER 1

#include "lwesp_opts.h"
#include "lwesp/lwesp_includes.h"
#include "lwesp/lwesp.h"
#include "lwesp/lwesp_sntp.h"
#include "lwesp/lwesp_ping.h"
#include "lwesp/apps/lwesp_mqtt_client_api.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

/* USER CODE END Variables */
/* Definitions for defaultTask */
osThreadId_t defaultTaskHandle;
const osThreadAttr_t defaultTask_attributes = {
	.name = "defaultTask",
	.priority = (osPriority_t)osPriorityNormal,
	.stack_size = 128 * 4
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */
void init_thread(void* argument);

/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void* argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void)
{
	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* USER CODE BEGIN RTOS_MUTEX */
	/* add mutexes, ... */
	/* USER CODE END RTOS_MUTEX */

	/* USER CODE BEGIN RTOS_SEMAPHORES */
	/* add semaphores, ... */
	/* USER CODE END RTOS_SEMAPHORES */

	/* USER CODE BEGIN RTOS_TIMERS */
	/* start timers, add new ones, ... */
	/* USER CODE END RTOS_TIMERS */

	/* USER CODE BEGIN RTOS_QUEUES */
	/* add queues, ... */
	/* USER CODE END RTOS_QUEUES */

	/* Create the thread(s) */
	/* creation of defaultTask */
//	defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);

	/* USER CODE BEGIN RTOS_THREADS */
	const osThreadAttr_t attr = {
		.stack_size = 1024
	};
	osThreadNew(init_thread, NULL, &attr);
	/* USER CODE END RTOS_THREADS */

	/* USER CODE BEGIN RTOS_EVENTS */
	/* add events, ... */
	/* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void* argument)
{
	/* USER CODE BEGIN StartDefaultTask */
	/* Infinite loop */
	for (;;)
	{
//		HAL_GPIO_TogglePin(LED_GPIO_Port, LED_Pin);
		osDelay(500);
	}
	/* USER CODE END StartDefaultTask */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */
lwespr_t examples_common_lwesp_callback_func(lwesp_evt_t* evt)
{
	lwesp_evt_type_t e =lwesp_evt_get_type(evt);
	switch (e)
	{
		case LWESP_EVT_AT_VERSION_NOT_SUPPORTED:
		{
			lwesp_sw_version_t v_min, v_curr;

			lwesp_get_min_at_fw_version(&v_min);
			lwesp_get_current_at_fw_version(&v_curr);

			printf("Current ESP[8266/32[-C3]] AT version is not supported by the library\r\n");
			printf("Minimum required AT version is: %08X\r\n", (unsigned)v_min.version);
			printf("Current AT version is: %08X\r\n", (unsigned)v_curr.version);
			break;
		}
		case LWESP_EVT_INIT_FINISH:
		{
			printf("Library initialized!\r\n");
			break;
		}
		case LWESP_EVT_RESET_DETECTED:
		{
			printf("Device reset detected!\r\n");
			break;
		}
		default:
			break;
	}
	return lwespOK;
}

void prv_cmd_event_fn(lwespr_t status, void* arg)
{
	printf("");
}

static lwesp_mqtt_client_api_p mqtt_client;

static void prv_mqtt_cb(lwesp_mqtt_client_p client, lwesp_mqtt_evt_t* evt)
{
	switch (lwesp_mqtt_client_evt_get_type(client, evt))
	{
		/*
		 * Connect event
		 * Called if user successfully connected to MQTT server
		 * or even if connection failed for some reason
		 */
		case LWESP_MQTT_EVT_CONNECT:
		{            /* MQTT connect event occurred */
			lwesp_mqtt_conn_status_t status = lwesp_mqtt_client_evt_connect_get_status(client, evt);

			if (status == LWESP_MQTT_CONN_STATUS_ACCEPTED)
			{
				printf("MQTT accepted!\r\n");
				/*
				 * Once we are accepted by server,
				 * it is time to subscribe to different topics
				 * We will subscrive to "mqtt_lwesp_example_topic" topic,
				 * and will also set the same name as subscribe argument for callback later
				 */
//				lwesp_mqtt_client_subscribe(client, "lwesp_topic", LWESP_MQTT_QOS_EXACTLY_ONCE, "lwesp_topic");

				/* Start timeout timer after 5000ms and call mqtt_timeout_cb function */
//				lwesp_timeout_add(5000, prv_mqtt_timeout_cb, client);
			}
			else
			{
				printf("MQTT server connection was not successful: %d\r\n", (int)status);

				/* Try to connect all over again */
//				prv_example_do_connect(client);
			}
			break;
		}

			/*
			 * Subscribe event just happened.
			 * Here it is time to check if it was successful or failed attempt
			 */
		case LWESP_MQTT_EVT_SUBSCRIBE:
		{
			const char* arg = lwesp_mqtt_client_evt_subscribe_get_argument(client, evt);  /* Get user argument */
			lwespr_t res = lwesp_mqtt_client_evt_subscribe_get_result(client, evt); /* Get result of subscribe event */

			if (res == lwespOK)
			{
				printf("Successfully subscribed to %s topic\r\n", arg);
				if (!strcmp(arg, "lwesp_topic"))
				{   /* Check topic name we were subscribed */
					/* Subscribed to "lwesp_topic" topic */

					/*
					 * Now publish an even on example topic
					 * and set QoS to minimal value which does not guarantee message delivery to received
					 */
//					lwesp_mqtt_client_publish(client, "lwesp_topic", "test_data", 9, LWESP_MQTT_QOS_AT_MOST_ONCE, 0, (void*)1);
				}
			}
			break;
		}

			/* Message published event occurred */
		case LWESP_MQTT_EVT_PUBLISH:
		{
			uint32_t val = (uint32_t)(uintptr_t)lwesp_mqtt_client_evt_publish_get_argument(client, evt);/* Get user argument, which is in fact our custom number */

			printf("Publish event, user argument on message was: %d\r\n", (int)val);
			break;
		}

			/*
			 * A new message was published to us
			 * and now it is time to read the data
			 */
		case LWESP_MQTT_EVT_PUBLISH_RECV:
		{
			const char* topic = lwesp_mqtt_client_evt_publish_recv_get_topic(client, evt);
			size_t topic_len = lwesp_mqtt_client_evt_publish_recv_get_topic_len(client, evt);
			const uint8_t* payload = lwesp_mqtt_client_evt_publish_recv_get_payload(client, evt);
			size_t payload_len = lwesp_mqtt_client_evt_publish_recv_get_payload_len(client, evt);

			LWESP_UNUSED(payload);
			LWESP_UNUSED(payload_len);
			LWESP_UNUSED(topic);
			LWESP_UNUSED(topic_len);
			break;
		}

			/* Client is fully disconnected from MQTT server */
		case LWESP_MQTT_EVT_DISCONNECT:
		{
			printf("MQTT client disconnected!\r\n");
//			prv_example_do_connect(client);         /* Connect to server all over again */
			break;
		}

		default:
			break;
	}
}

void init_thread(void* arg)
{
	/* Initialize ESP with common callback for all examples */
	printf("Initializing LwESP\r\n");
	if (lwesp_init(examples_common_lwesp_callback_func, 1) != lwespOK)
	{
		printf("Cannot initialize LwESP!\r\n");
	}
	else
	{
		printf("LwESP initialized!\r\n");
	}

//	lwesp_reset(NULL, 0, 1);
//	lwesp_mode_t mode = LWESP_MODE_STA;
//	lwesp_set_wifi_mode(mode, NULL, NULL, 1);

	mqtt_client = lwesp_mqtt_client_api_new(256, 128);;
	while (1)
	{
		if (!lwesp_sta_is_joined())
		{
//			lwesp_ap_t ap_list_scanned[5];         /* Scanned access points information */
//			size_t ap_list_scanned_len = 0;
//			lwesp_sta_list_ap(NULL, ap_list_scanned, LWESP_ARRAYSIZE(ap_list_scanned), &ap_list_scanned_len, NULL, NULL, 1);
			if (lwesp_sta_join("SauronNet.Horcicka1", "10821082", NULL, NULL, 0, 1) == lwespOK)
			{
				HAL_GPIO_TogglePin(LED_GPIO_Port, LED_Pin);

				lwesp_ip_t ip = { };
				lwesp_sta_copy_ip(&ip, NULL, NULL, NULL);

				printf("Connected to AP %d\n", ip.addr.ip4.addr[0]);

//				lwesp_mqtt_client_info_t i = {
//					.id = "lesptest",
//					.keep_alive = 120,
//					.user = "test",
//					.pass = "test",
////				.use_ssl=1
//				};
//
//				lwesp_mqtt_conn_status_t conn_status = lwesp_mqtt_client_api_connect(mqtt_client, "itorius.com", 1883, &i);
//				if (conn_status == LWESP_MQTT_CONN_STATUS_ACCEPTED)
//				{
//					printf("Connected and accepted!\r\n");
//					printf("Client is ready to subscribe and publish to new messages\r\n");
//
//					char* mqtt_topic_data = "teststr";
//					lwesp_mqtt_client_api_publish(mqtt_client, "/test_data", mqtt_topic_data, strlen(mqtt_topic_data), LWESP_MQTT_QOS_AT_LEAST_ONCE, 0);
//				}
//				else
//				{
//					printf("Connect API response: %d\r\n", (int)conn_status);
//					lwesp_delay(5000);
//				}

//				lwesp_mqtt_client_connect(mqtt_client, "test.mosquitto.org", 1883, prv_mqtt_cb, &i);
			}
		}

		osDelay(5000);
	}

//	while (1)
//	{
//
//	}
}
/* USER CODE END Application */

